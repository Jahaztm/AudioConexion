package BaseDeDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Modelo.Cancion;

public class CancionDBImp implements CancionBD {
	
	private AdminBD admin;
	private Connection conexion;
	private boolean conexione;
	
	public CancionDBImp()
	{
		admin = new AdminBD();
		conexion = null;
	}
	
	public CancionDBImp(Connection conexion)
	{
		this.conexion=conexion;
		conexione=true;
	}
	@Override
	public List<Cancion> consultar() 
	{
		PreparedStatement ps=null;
		ResultSet rs=null;
		Cancion cancion= null;
		List <Cancion> canciones = new ArrayList<Cancion>();
		
		String sql = "SELECT nombre, autor, album, numeroc FROM audio;";
		
		try {
			conexion=admin.dameConexion();
			ps=conexion.prepareStatement(sql);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				cancion = new Cancion();
				cancion.setNombre(rs.getString("nombre"));
				cancion.setAutor(rs.getString("autor"));
				cancion.setAlbum(rs.getString("album"));
				cancion.setNumeroc(rs.getInt("numeroc"));
				canciones.add(cancion);
			}
			rs.close();
			ps.close();
			conexion.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return canciones;
	}

	@Override
	public int instertar(Cancion cancion) 
	{
		int track = 0 ;
		PreparedStatement ps=null;
		String sql = "INSERT INTO audio(nombre,autor,album,numeroc) VALUES(?,?,?,?);";
		if(conexione==false)
			conexion=admin.dameConexion();
		
		try {
			ps=conexion.prepareStatement(sql);
			ps.setString(1, cancion.getNombre());
			ps.setString(2, cancion.getAutor());
			ps.setString(3, cancion.getAlbum());
			ps.setInt(4, cancion.getNumeroc());
			track = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally 
		{
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return track;
	} 
	
	public static void main(String args[]) 
	{
		CancionDBImp canciondb = new CancionDBImp();
		Scanner teclado = new Scanner(System.in);
		int op = 0;
		System.out.println("1) INSERTAR\n2)Consultar");
		op = teclado.nextInt();
		switch (op) {
		case 1:
		{
			Cancion cancion = new Cancion();
			cancion.setNombre("Love me two times");
			cancion.setAutor("The Doors");
			cancion.setAlbum("Album 1");
			cancion.setNumeroc(3);
			
			canciondb.instertar(cancion);
		}
			
			break;
		case 2:
		{
			List<Cancion> canciones = null;
			canciones=canciondb.consultar();
			for (int i = 0; i < canciones.size(); i++)
			{
				System.out.println(""+canciones.get(i));
			}
		}
			
			break;

		default:
			System.out.println("Opcion equivocada");
			break;
		}
		
	}

}
