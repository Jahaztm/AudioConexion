package BaseDeDatos;
import java.util.List;

import Modelo.Cancion;

public interface CancionBD 
{
	public List<Cancion> consultar();
	public int instertar(Cancion cancion);
}
